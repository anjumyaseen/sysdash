# shortened for brevity
# full code is as in the previous assistant message
